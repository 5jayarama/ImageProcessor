/**
 * The main method.
 */
public class Main {
  /**
   * Takes in an argument to run a Hello World main method.
   * @param args the given argument.
   */
  public static void main(String[] args) {
    System.out.println("Hello world!");
  }
}